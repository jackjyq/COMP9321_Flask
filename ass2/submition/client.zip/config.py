URL_SERVER='http://127.0.0.1:5000/'

# debug, should be keep false when deploy
PRINT_INFO = False

# true for realy URL
# false for resource.mcndsj
# if false, then apply capitalize name
LGANAME_LOWER = True